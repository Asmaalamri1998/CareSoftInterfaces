module CareSoftInterfaces {
	
	
}